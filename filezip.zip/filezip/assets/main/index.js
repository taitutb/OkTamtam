window.__require = function e(t, n, s) {
function a(r, i) {
if (!n[r]) {
if (!t[r]) {
var c = r.split("/");
c = c[c.length - 1];
if (!t[c]) {
var l = "function" == typeof __require && __require;
if (!i && l) return l(c, !0);
if (o) return o(c, !0);
throw new Error("Cannot find module '" + r + "'");
}
r = c;
}
var p = n[r] = {
exports: {}
};
t[r][0].call(p.exports, function(e) {
return a(t[r][1][e] || e);
}, p, p.exports, e, t, n, s);
}
return n[r].exports;
}
for (var o = "function" == typeof __require && __require, r = 0; r < s.length; r++) a(s[r]);
return a;
}({
HotUpdate: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "769d6sQ8KRNN6FpJZX8q6Pn", "HotUpdate");
var s, a = this && this.__extends || (s = function(e, t) {
return (s = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
})(e, t);
}, function(e, t) {
s(e, t);
function n() {
this.constructor = e;
}
e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n());
}), o = this && this.__decorate || function(e, t, n, s) {
var a, o = arguments.length, r = o < 3 ? t : null === s ? s = Object.getOwnPropertyDescriptor(t, n) : s;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(e, t, n, s); else for (var i = e.length - 1; i >= 0; i--) (a = e[i]) && (r = (o < 3 ? a(r) : o > 3 ? a(t, n, r) : a(t, n)) || r);
return o > 3 && r && Object.defineProperty(t, n, r), r;
};
Object.defineProperty(n, "__esModule", {
value: !0
});
var r = cc._decorator, i = r.ccclass, c = r.property, l = e("NetConfig"), p = function(e) {
a(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.manifestUrl = null;
t.loadingBar = null;
t.lb_Info = null;
t._updating = !1;
t._failCount = 0;
t._canRetry = !1;
t._storagePath = "";
t._updateListener = null;
t._am = null;
t._checkListener = null;
t.versionCompareHandle = null;
t.gameSceneName = "main";
t.isLoadingDone = !1;
t.isSetCookieDone = !1;
return t;
}
t.prototype.onLoad = function() {
cc.sys.isNative && (cc.Device ? cc.Device.setKeepScreenOn(!0) : jsb.Device && jsb.Device.setKeepScreenOn(!0));
this.initHotUpdate();
};
t.prototype.requestConfig = function() {
var e = this, t = "https://api." + l.HOST + "/api/v1/games/config";
cc.ServerConnector.getInstance().sendGetNew(t, {
service_id: 1
}, function(t) {
var n = JSON.parse(t);
if (n && 1 == n.success) {
cc.sys.localStorage.setItem("configServer", JSON.stringify(n.data));
e.isSetCookieDone = !0;
e.isLoadingDone && cc.director.loadScene("lobby");
}
});
};
t.prototype.initHotUpdate = function() {
this._storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + "hot4-remote-asset";
cc.log("Storage path for remote asset : " + this._storagePath);
this.versionCompareHandle = function(e, t) {
cc.log("JS Custom Version Compare: version A is " + e + ", version B is " + t);
for (var n = e.split("."), s = t.split("."), a = 0; a < n.length; ++a) {
var o = parseInt(n[a]), r = parseInt(s[a] || 0);
if (o !== r) return o - r;
}
return s.length > n.length ? -1 : 0;
};
this._am = new jsb.AssetsManager("", this._storagePath, this.versionCompareHandle);
this._am.setVerifyCallback(function(e, t) {
t.compressed;
return !0;
});
cc.sys.os === cc.sys.OS_ANDROID && this._am.setMaxConcurrentTask(2);
this.hotUpdate();
};
t.prototype.loadGame = function() {
var e = this, t = 0;
e.loadingBar.fillRange = 0;
e.lb_Info.string = "Đang Tải Game...";
console.log("lobby");
cc.director.preloadScene("lobby", function(n, s) {
var a = 100 * n / s;
a > t && (t = a);
e.loadingBar.fillRange = t / 100;
e.lb_Info.string = "Đang Tải Game...";
}, function() {
e.isLoadingDone = !0;
e.isSetCookieDone && cc.director.loadScene("lobby");
});
};
t.prototype.updateCb = function(e) {
var t = !1, n = !1;
cc.log("---eventCode:" + e.getEventCode());
switch (e.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
n = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
var s = e.getMessage();
s && cc.log("Progress" + e.getPercent() / 100 + "% : " + s);
this.loadingBar.fillRange = e.getPercent();
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
n = !0;
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
n = !0;
this.loadGame();
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
t = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
this._updating = !1;
this._canRetry = !0;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
case jsb.EventAssetsManager.ERROR_DECOMPRESS:
}
cc.log("---needStar" + t);
if (n) {
this._am.setEventCallback(null);
this._updateListener = null;
this._updating = !1;
}
if (t) {
this._am.setEventCallback(null);
this._updateListener = null;
var a = jsb.fileUtils.getSearchPaths(), o = this._am.getLocalManifest().getSearchPaths();
cc.log(JSON.stringify(o));
Array.prototype.unshift.apply(a, o);
cc.sys.localStorage.setItem("HotUpdateSearchPaths", JSON.stringify(a));
jsb.fileUtils.setSearchPaths(a);
cc.audioEngine.stopAll();
cc.game.restart();
}
};
t.prototype.hotUpdate = function() {
if (this._am && !this._updating) {
this._am.setEventCallback(this.updateCb.bind(this));
if (this._am.getState() === jsb.AssetsManager.State.UNINITED) {
var e = this.manifestUrl.nativeUrl;
cc.loader.md5Pipe && (e = cc.loader.md5Pipe.transformURL(e));
this._am.loadLocalManifest(e);
}
this._failCount = 0;
this._am.update();
this._updating = !0;
}
};
t.prototype.onDestroy = function() {
if (this._updateListener) {
this._am.setEventCallback(null);
this._updateListener = null;
}
};
o([ c({
type: cc.Asset
}) ], t.prototype, "manifestUrl", void 0);
o([ c(cc.Sprite) ], t.prototype, "loadingBar", void 0);
o([ c(cc.Label) ], t.prototype, "lb_Info", void 0);
return o([ i ], t);
}(cc.Component);
n.default = p;
cc._RF.pop();
}, {
NetConfig: "NetConfig"
} ],
LoadGameController: [ function(e, t, n) {
"use strict";
cc._RF.push(t, "89e3bULnINAO5LStk1zefH7", "LoadGameController");
var s, a = this && this.__extends || (s = function(e, t) {
return (s = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
})(e, t);
}, function(e, t) {
s(e, t);
function n() {
this.constructor = e;
}
e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n());
}), o = this && this.__decorate || function(e, t, n, s) {
var a, o = arguments.length, r = o < 3 ? t : null === s ? s = Object.getOwnPropertyDescriptor(t, n) : s;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(e, t, n, s); else for (var i = e.length - 1; i >= 0; i--) (a = e[i]) && (r = (o < 3 ? a(r) : o > 3 ? a(t, n, r) : a(t, n)) || r);
return o > 3 && r && Object.defineProperty(t, n, r), r;
}, r = this && this.__awaiter || function(e, t, n, s) {
return new (n || (n = Promise))(function(a, o) {
function r(e) {
try {
c(s.next(e));
} catch (e) {
o(e);
}
}
function i(e) {
try {
c(s.throw(e));
} catch (e) {
o(e);
}
}
function c(e) {
e.done ? a(e.value) : (t = e.value, t instanceof n ? t : new n(function(e) {
e(t);
})).then(r, i);
var t;
}
c((s = s.apply(e, t || [])).next());
});
}, i = this && this.__generator || function(e, t) {
var n, s, a, o, r = {
label: 0,
sent: function() {
if (1 & a[0]) throw a[1];
return a[1];
},
trys: [],
ops: []
};
return o = {
next: i(0),
throw: i(1),
return: i(2)
}, "function" == typeof Symbol && (o[Symbol.iterator] = function() {
return this;
}), o;
function i(e) {
return function(t) {
return c([ e, t ]);
};
}
function c(o) {
if (n) throw new TypeError("Generator is already executing.");
for (;r; ) try {
if (n = 1, s && (a = 2 & o[0] ? s.return : o[0] ? s.throw || ((a = s.return) && a.call(s), 
0) : s.next) && !(a = a.call(s, o[1])).done) return a;
(s = 0, a) && (o = [ 2 & o[0], a.value ]);
switch (o[0]) {
case 0:
case 1:
a = o;
break;

case 4:
r.label++;
return {
value: o[1],
done: !1
};

case 5:
r.label++;
s = o[1];
o = [ 0 ];
continue;

case 7:
o = r.ops.pop();
r.trys.pop();
continue;

default:
if (!(a = r.trys, a = a.length > 0 && a[a.length - 1]) && (6 === o[0] || 2 === o[0])) {
r = 0;
continue;
}
if (3 === o[0] && (!a || o[1] > a[0] && o[1] < a[3])) {
r.label = o[1];
break;
}
if (6 === o[0] && r.label < a[1]) {
r.label = a[1];
a = o;
break;
}
if (a && r.label < a[2]) {
r.label = a[2];
r.ops.push(o);
break;
}
a[2] && r.ops.pop();
r.trys.pop();
continue;
}
o = t.call(e, r);
} catch (e) {
o = [ 6, e ];
s = 0;
} finally {
n = a = 0;
}
if (5 & o[0]) throw o[1];
return {
value: o[0] ? o[1] : void 0,
done: !0
};
}
};
Object.defineProperty(n, "__esModule", {
value: !0
});
var c = cc._decorator, l = c.ccclass, p = c.property;
function u(e, t) {
for (var n = e.split("."), s = t.split("."), a = 0; a < n.length; ++a) {
var o = parseInt(n[a]), r = parseInt(s[a] || "0");
if (o !== r) return o - r;
}
return s.length > n.length ? -1 : 0;
}
var f = function(e) {
a(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.loadingSprite = null;
t.loadingLabel = null;
t._updating = !1;
t._canRetry = !1;
t._storagePath = "";
t.stringHost = "";
t._am = null;
t._checkListener = null;
t._updateListener = null;
t.count = 0;
return t;
}
t.prototype.onLoad = function() {
if (jsb) {
this._storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + "remote-asset";
this._am = new jsb.AssetsManager("", this._storagePath, u);
this._am.setVerifyCallback(function(e, t) {
var n = t.compressed, s = t.md5, a = t.path;
t.size;
if (n) {
cc.log("Verification passed : " + a);
return !0;
}
cc.log("Verification passed : " + a + " (" + s + ")");
return !0;
});
}
};
t.prototype.onDestroy = function() {
if (this._updateListener) {
this._am.setEventCallback(null);
this._updateListener = null;
}
};
t.prototype.start = function() {
return r(this, void 0, void 0, function() {
var e = this;
return i(this, function() {
this.schedule(function() {
e.count += .01;
e.updateProcess(e.count);
e.count >= 1 && e.loadMyGame();
}, .03);
cc.sys.isMobile && this.onCheckGame("https://hot4.geanekw.top/remote-assets/LoadingScene");
return [ 2 ];
});
});
};
t.prototype.loadMyGame = function() {
this.unscheduleAllCallbacks();
cc.director.loadScene("HomeScene");
};
t.prototype.onCheckGame = function(e) {
this.unscheduleAllCallbacks();
this.stringHost = e;
this.hotUpdate();
};
t.prototype.loadCustomManifest = function(e) {
var t, n = new jsb.Manifest((t = e, JSON.stringify({
packageUrl: t + "/",
remoteManifestUrl: t + "/project.manifest",
remoteVersionUrl: t + "/version.manifest",
version: "0.0.0",
assets: {},
searchPaths: []
})), this._storagePath);
this._am.loadLocalManifest(n, this._storagePath);
};
t.prototype.updateCb = function(e) {
var t = !1, n = !1;
switch (e.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
cc.log("No local manifest file found, hot update skipped.");
n = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
var s = e.getDownloadedFiles() / e.getTotalFiles();
e.getMessage();
this.updateProcess(s);
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
cc.log("Fail to download manifest file, hot update skipped.");
n = !0;
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
cc.log("Already up to date with the latest remote version.");
t = !0;
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
cc.log("Update finished. " + e.getMessage());
t = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
cc.log("Update failed. " + e.getMessage());
this._updating = !1;
this._canRetry = !0;
n = !0;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
cc.log("Asset update error: " + e.getAssetId() + ", " + e.getMessage());
n = !0;
break;

case jsb.EventAssetsManager.ERROR_DECOMPRESS:
cc.log(e.getMessage());
n = !0;
}
if (n) {
this._am.setEventCallback(null);
this._updateListener = null;
this._updating = !1;
this.loadMyGame();
}
if (t) {
this._am.setEventCallback(null);
this._updateListener = null;
var a = jsb.fileUtils.getSearchPaths(), o = this._am.getLocalManifest().getSearchPaths();
Array.prototype.unshift.apply(a, o);
cc.sys.localStorage.setItem("HotUpdateSearchPaths", JSON.stringify(a));
jsb.fileUtils.setSearchPaths(a);
setTimeout(function() {
cc.game.restart();
}, 500);
}
};
t.prototype.hotUpdate = function() {
if (this._am && !this._updating) {
this._am.setEventCallback(this.updateCb.bind(this));
this.loadCustomManifest(this.stringHost);
this._am.update();
this._updating = !0;
}
};
t.prototype.updateProcess = function(e) {
cc.log("Updated file: " + e);
this.loadingSprite.fillRange = e;
this.loadingLabel.string = "Update " + Math.round(100 * e) + "%";
};
o([ p(cc.Sprite) ], t.prototype, "loadingSprite", void 0);
o([ p(cc.Label) ], t.prototype, "loadingLabel", void 0);
return o([ l ], t);
}(cc.Component);
n.default = f;
cc._RF.pop();
}, {} ],
NetConfig: [ function(e, t) {
"use strict";
cc._RF.push(t, "7f5f1YFdXhJIp24qIls1s3W", "NetConfig");
t.exports = {
HOST: "steel1.top",
HOST_COOKIE: "steel1.top"
};
cc._RF.pop();
}, {} ]
}, {}, [ "HotUpdate", "LoadGameController", "NetConfig" ]);